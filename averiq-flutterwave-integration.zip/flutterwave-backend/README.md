# AVERIQ + Flutterwave backend starter

This backend prepares AVERIQ for Nigerian bank-account verification and Flutterwave payouts.

## Run

1. Install Node.js 18+.
2. Copy `.env.example` to `.env`.
3. Put your Flutterwave **secret key** in `.env`.
4. Run `npm install`.
5. Run `npm start`.
6. Keep `DEMO_MODE=true` while testing.

## Important

The HTML app must never contain `FLW_SECRET_KEY`. It belongs only on the server.

The current AVERIQ browser balance is localStorage-based. That is not secure enough to authorize a real payout. The `POST /api/gift-cards/redeem` endpoint therefore refuses real transfers until a server-side AVQ ledger/blockchain verification layer is connected.

Flutterwave flow prepared here:
- `GET /api/banks/ng` — retrieve Nigerian banks.
- `POST /api/resolve-account` — resolve a 10-digit Nigerian bank account.
- `POST /api/gift-cards/redeem` — redemption entry point.
- `POST /api/webhooks/flutterwave` — payout webhook entry point.

For production, use an authenticated user identity, an atomic database transaction, AVQ verification, idempotency, reserve checks, and webhook verification before issuing value.

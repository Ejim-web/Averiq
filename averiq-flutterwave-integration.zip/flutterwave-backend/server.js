require('dotenv').config();
const express = require('express');
const cors = require('cors');
const crypto = require('crypto');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const FLW_SECRET_KEY = process.env.FLW_SECRET_KEY || '';
const FLW_WEBHOOK_SECRET = process.env.FLW_WEBHOOK_SECRET || '';
const FLW_BASE = process.env.FLW_LIVE === 'true' ? 'https://api.flutterwave.com/v3' : 'https://api.flutterwave.com/v3';
const DEMO_MODE = process.env.DEMO_MODE !== 'false';

app.use(cors({ origin: process.env.AVERIQ_FRONTEND_ORIGIN || true }));
app.use(express.json({ limit: '100kb' }));

const giftCards = {
  gc500: { id: 'gc500', value: 500, cost: 1000 },
  gc1000: { id: 'gc1000', value: 1000, cost: 2000 },
  gc2500: { id: 'gc2500', value: 2500, cost: 5000 }
};

function requireFlutterwave() {
  if (!FLW_SECRET_KEY || FLW_SECRET_KEY.includes('REPLACE_ME')) {
    const err = new Error('Flutterwave secret key is not configured on the server.');
    err.status = 503;
    throw err;
  }
}

async function flw(path, options = {}) {
  requireFlutterwave();
  const response = await fetch(`${FLW_BASE}${path}`, {
    ...options,
    headers: {
      Authorization: `Bearer ${FLW_SECRET_KEY}`,
      'Content-Type': 'application/json',
      ...(options.headers || {})
    }
  });
  const text = await response.text();
  let body;
  try { body = JSON.parse(text); } catch { body = { raw: text }; }
  if (!response.ok) {
    const err = new Error(body?.message || `Flutterwave HTTP ${response.status}`);
    err.status = response.status;
    err.body = body;
    throw err;
  }
  return body;
}

app.get('/api/health', (req, res) => {
  res.json({ ok: true, provider: 'flutterwave', demoMode: DEMO_MODE, live: process.env.FLW_LIVE === 'true' });
});

app.get('/api/banks/ng', async (req, res) => {
  try {
    const result = await flw('/banks/NG?include_provider_type=1', { method: 'GET' });
    res.json(result);
  } catch (e) {
    res.status(e.status || 500).json({ status: 'error', message: e.message, details: e.body || null });
  }
});

app.post('/api/resolve-account', async (req, res) => {
  try {
    const account_number = String(req.body.account_number || '').replace(/\D/g, '');
    const account_bank = String(req.body.account_bank || '').trim();
    if (!/^\d{10}$/.test(account_number) || !account_bank) {
      return res.status(400).json({ status: 'error', message: 'Enter a valid 10-digit Nigerian account number and bank code.' });
    }
    const result = await flw('/accounts/resolve', {
      method: 'POST',
      body: JSON.stringify({ account_number, account_bank })
    });
    res.json(result);
  } catch (e) {
    res.status(e.status || 500).json({ status: 'error', message: e.message, details: e.body || null });
  }
});

/*
  This endpoint is intentionally NOT a production AVQ accounting system.
  Before enabling real-value redemptions, replace the demo balance check below
  with your authenticated server-side AVQ ledger / verified on-chain balance.
*/
app.post('/api/gift-cards/redeem', async (req, res) => {
  const { cardId, account_bank, account_number, beneficiary_name, userId } = req.body || {};
  const card = giftCards[cardId];
  if (!card) return res.status(400).json({ status: 'error', message: 'Unknown gift card.' });
  if (!/^\d{10}$/.test(String(account_number || ''))) {
    return res.status(400).json({ status: 'error', message: 'A valid 10-digit Nigerian bank account is required.' });
  }
  if (!account_bank) return res.status(400).json({ status: 'error', message: 'Bank code is required.' });
  if (!beneficiary_name) return res.status(400).json({ status: 'error', message: 'Beneficiary name is required.' });
  if (!userId) return res.status(400).json({ status: 'error', message: 'Authenticated AVERIQ user ID is required.' });

  // IMPORTANT: This starter deliberately refuses to issue real money in DEMO_MODE.
  // It shows exactly where the secure AVQ ledger and Flutterwave transfer belong.
  if (DEMO_MODE) {
    return res.json({
      status: 'demo',
      message: 'Flutterwave integration is prepared, but DEMO_MODE is enabled. No real transfer was made.',
      redemption: {
        id: `demo_${crypto.randomUUID()}`,
        userId,
        cardId: card.id,
        value: card.value,
        avqCost: card.cost,
        status: 'PENDING_BACKEND_LEDGER',
        accountNumber: String(account_number).slice(-4).padStart(10, '*')
      }
    });
  }

  try {
    // TODO: Replace with an atomic database transaction:
    // 1) authenticate user
    // 2) verify AVQ balance >= card.cost
    // 3) reserve/deduct AVQ
    // 4) create redemption row with unique reference
    // 5) only then initiate Flutterwave transfer
    // 6) finalize/reverse the AVQ reservation based on webhook outcome
    throw Object.assign(new Error('Production AVQ ledger is not connected yet. Refusing to send real money.'), { status: 503 });
  } catch (e) {
    res.status(e.status || 500).json({ status: 'error', message: e.message });
  }
});

app.post('/api/webhooks/flutterwave', (req, res) => {
  const signature = req.get('flutterwave-signature') || req.get('verif-hash');
  if (FLW_WEBHOOK_SECRET && signature !== FLW_WEBHOOK_SECRET) {
    return res.status(401).json({ status: 'error', message: 'Invalid webhook signature.' });
  }

  // Production handler should:
  // - identify the redemption by reference/transfer id
  // - re-query Flutterwave to verify status, amount and currency
  // - mark payout SUCCESSFUL/FAILED exactly once (idempotent)
  // - settle or reverse the reserved AVQ in your database
  console.log('Flutterwave webhook received:', JSON.stringify(req.body));
  return res.status(200).json({ status: 'success' });
});

app.listen(PORT, () => {
  console.log(`AVERIQ Flutterwave backend listening on http://localhost:${PORT}`);
  console.log(`DEMO_MODE=${DEMO_MODE}; FLW_LIVE=${process.env.FLW_LIVE === 'true'}`);
});

# Averiq AVQ — Solana Devnet blockchain setup

## What this package does

- 24-hour earning session is controlled by Firebase server timestamps.
- Phantom supplies only the user's public Solana address.
- Firebase Cloud Functions verify the completed session.
- The reward function mints AVQ to the user's Solana token account.
- The AVQ mint authority private key stays on the server as a Firebase secret.

## 1. Create AVQ on Devnet

In Solana Playground:

```bash
solana config set --url devnet
spl-token create-token --decimals 6
```

Copy the returned mint address. Create the reward wallet/token account as needed and make sure the wallet that will sign `mintTo` is the mint authority.

Do not put the mint authority private key in `index.html`.

## 2. Enable Anonymous Authentication

Firebase Console → Authentication → Sign-in method → Anonymous → Enable.

## 3. Install and deploy Functions

From this folder:

```bash
cd functions
npm install
cd ..
firebase deploy --only functions,firestore:rules
```

Firebase Cloud Functions production deployment requires the Blaze plan.

## 4. Configure the AVQ mint and reward wallet

Set the mint address as a Functions environment variable:

```bash
firebase functions:secrets:set SOLANA_REWARD_PRIVATE_KEY
```

Paste the JSON array returned by the reward wallet's secret key export when prompted. Never send that secret to anyone.

Then set `AVQ_MINT_ADDRESS` in the Functions runtime environment using your preferred Firebase/Google Cloud configuration method, or replace the empty fallback in `functions/index.js` before deployment.

Also set `SOLANA_RPC_URL=https://api.devnet.solana.com` if you want to make the RPC explicit.

## 5. Put the mint address into the website

In `index.html`, replace:

```js
const AVQ_MINT_ADDRESS = "PASTE_YOUR_AVQ_DEVNET_MINT_ADDRESS_HERE";
```

with the real Devnet AVQ mint address.

## 6. Deploy the website

Upload `index.html` to the root of your GitHub Pages repository.

## Important

Devnet AVQ is for testing and has no real monetary value. Before Mainnet, audit the reward rules, supply, mint authority, abuse protection, token distribution, liquidity plan, and legal/compliance requirements.

const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { defineSecret } = require('firebase-functions/params');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue, Timestamp } = require('firebase-admin/firestore');
const { Keypair, PublicKey, Connection, clusterApiUrl } = require('@solana/web3.js');
const { getAssociatedTokenAddress, getAccount, createAssociatedTokenAccountInstruction, getMint, mintTo, TOKEN_PROGRAM_ID } = require('@solana/spl-token');

initializeApp();
const db = getFirestore();
const SOLANA_RPC_URL = process.env.SOLANA_RPC_URL || clusterApiUrl('devnet');
const AVQ_MINT_ADDRESS = process.env.AVQ_MINT_ADDRESS || '';
const REWARD_PRIVATE_KEY = defineSecret('SOLANA_REWARD_PRIVATE_KEY');
const SESSION_MS = 24 * 60 * 60 * 1000;
const REWARD_AVQ = 1;

function requireAuth(req) {
  if (!req.auth || !req.auth.uid) {
    throw new HttpsError('unauthenticated', 'Sign in to Averiq first.');
  }
  return req.auth.uid;
}

function validWallet(value) {
  try {
    return new PublicKey(value);
  } catch (_) {
    throw new HttpsError('invalid-argument', 'Invalid Solana wallet address.');
  }
}

function rewardKeypair() {
  if (!REWARD_PRIVATE_KEY.value()) {
    throw new HttpsError('failed-precondition', 'Reward wallet is not configured.');
  }
  let raw;
  try { raw = JSON.parse(REWARD_PRIVATE_KEY.value()); } catch (_) {
    throw new HttpsError('failed-precondition', 'SOLANA_REWARD_PRIVATE_KEY must be a JSON array.');
  }
  return Keypair.fromSecretKey(Uint8Array.from(raw));
}

function requireMint() {
  if (!AVQ_MINT_ADDRESS) {
    throw new HttpsError('failed-precondition', 'AVQ_MINT_ADDRESS is not configured.');
  }
  try { return new PublicKey(AVQ_MINT_ADDRESS); } catch (_) {
    throw new HttpsError('failed-precondition', 'AVQ_MINT_ADDRESS is invalid.');
  }
}

exports.startEarningSession = onCall({ region: 'us-central1', secrets: [REWARD_PRIVATE_KEY] }, async (req) => {
  const uid = requireAuth(req);
  const wallet = validWallet(req.data?.walletAddress);
  const userRef = db.collection('users').doc(uid);
  const sessionRef = userRef.collection('earningSessions').doc('current');
  const now = Date.now();

  const result = await db.runTransaction(async (tx) => {
    const [userSnap, sessionSnap] = await Promise.all([tx.get(userRef), tx.get(sessionRef)]);
    const user = userSnap.exists ? userSnap.data() : {};
    const existing = sessionSnap.exists ? sessionSnap.data() : null;

    if (existing && existing.status === 'active' && existing.endAt && existing.endAt.toMillis() > now) {
      return { alreadyActive: true, startedAt: existing.startedAt.toMillis(), endAt: existing.endAt.toMillis() };
    }

    const startedAt = Timestamp.fromMillis(now);
    const endAt = Timestamp.fromMillis(now + SESSION_MS);
    tx.set(userRef, {
      walletAddress: wallet.toBase58(),
      updatedAt: FieldValue.serverTimestamp()
    }, { merge: true });
    tx.set(sessionRef, {
      status: 'active',
      walletAddress: wallet.toBase58(),
      startedAt,
      endAt,
      rewardAvq: REWARD_AVQ,
      claimed: false,
      updatedAt: FieldValue.serverTimestamp()
    });
    return { alreadyActive: false, startedAt: now, endAt: now + SESSION_MS };
  });

  return result;
});

exports.getEarningSession = onCall({ region: 'us-central1', secrets: [REWARD_PRIVATE_KEY] }, async (req) => {
  const uid = requireAuth(req);
  const snap = await db.collection('users').doc(uid).collection('earningSessions').doc('current').get();
  if (!snap.exists) return { active: false, completed: false };
  const d = snap.data();
  const endAt = d.endAt?.toMillis?.() || 0;
  return {
    active: d.status === 'active' && endAt > Date.now(),
    completed: d.status === 'completed',
    claimed: !!d.claimed,
    startedAt: d.startedAt?.toMillis?.() || 0,
    endAt,
    rewardAvq: Number(d.rewardAvq || 0)
  };
});

exports.claimAvq = onCall({ region: 'us-central1', secrets: [REWARD_PRIVATE_KEY] }, async (req) => {
  const uid = requireAuth(req);
  const wallet = validWallet(req.data?.walletAddress);
  const mint = requireMint();
  const sessionRef = db.collection('users').doc(uid).collection('earningSessions').doc('current');
  const snap = await sessionRef.get();
  if (!snap.exists) throw new HttpsError('failed-precondition', 'No earning session exists.');
  const d = snap.data();
  const endAt = d.endAt?.toMillis?.() || 0;
  if (endAt > Date.now()) throw new HttpsError('failed-precondition', 'Your 24-hour earning session is not complete yet.');
  if (d.claimed || d.status === 'claimed') throw new HttpsError('already-exists', 'This session has already been claimed.');
  if (d.walletAddress !== wallet.toBase58()) throw new HttpsError('permission-denied', 'Wallet does not match the earning session.');

  await sessionRef.update({ status: 'processing', processingAt: FieldValue.serverTimestamp() });

  try {
    const payer = rewardKeypair();
    const connection = new Connection(SOLANA_RPC_URL, 'confirmed');
    const mintInfo = await getMint(connection, mint, 'confirmed', TOKEN_PROGRAM_ID);
    const recipientAta = await getAssociatedTokenAddress(mint, wallet, false, TOKEN_PROGRAM_ID);
    let ataExists = true;
    try { await getAccount(connection, recipientAta, 'confirmed', TOKEN_PROGRAM_ID); } catch (_) { ataExists = false; }

    if (!ataExists) {
      const { Transaction, sendAndConfirmTransaction } = require('@solana/web3.js');
      const tx = new Transaction().add(createAssociatedTokenAccountInstruction(
        payer.publicKey, recipientAta, wallet, mint, TOKEN_PROGRAM_ID
      ));
      await sendAndConfirmTransaction(connection, tx, [payer], { commitment: 'confirmed' });
    }

    const amount = BigInt(Math.round(REWARD_AVQ * 10 ** mintInfo.decimals));
    const signature = await mintTo(connection, payer, mint, recipientAta, payer, amount, [], { commitment: 'confirmed' }, TOKEN_PROGRAM_ID);

    await sessionRef.update({ status: 'claimed', claimed: true, claimedAt: FieldValue.serverTimestamp(), signature, recipientAta: recipientAta.toBase58() });
    return { success: true, signature, amountAvq: REWARD_AVQ, mint: mint.toBase58(), recipientAta: recipientAta.toBase58() };
  } catch (error) {
    await sessionRef.update({ status: 'active', lastError: String(error?.message || error), updatedAt: FieldValue.serverTimestamp() });
    throw new HttpsError('internal', 'Blockchain reward failed. Your session was not marked as claimed.');
  }
});
